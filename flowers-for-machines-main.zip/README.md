# flowers-for-machines
The last problem of the HUMANKIND -- NBT Block Importing, and here is the final solution.
